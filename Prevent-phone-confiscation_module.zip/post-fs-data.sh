#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}

# 这个脚本将以 post-fs-data 模式执行
# 更多信息请访问 Magisk 主题

# 设置倒计时初始值（以秒为单位）
countdown=259200
is_screen_on=false

while true; do
    # 判断屏幕状态
    screen_status=$(dumpsys power | grep 'mScreenOn=')
    if [[ $screen_status == *"mScreenOn=true"* ]]; then
        # 屏幕亮屏
        is_screen_on=true
    else
        # 屏幕息屏
        is_screen_on=false
    fi

    if [ "$is_screen_on" = false ]; then
        # 倒计时开始
        for ((i=countdown; i>0; i--)); do
            # 检查屏幕状态是否发生改变，如果亮屏则等待屏幕再次息屏
            screen_status=$(dumpsys power | grep 'mScreenOn=')
            while [[ $screen_status == *"mScreenOn=true"* ]]; do
                sleep 1
                screen_status=$(dumpsys power | grep 'mScreenOn=')
            done

            # 检查是否有动作触发（屏幕再次亮屏），如果有则重新倒计
            if [[ $screen_status == *"mScreenOn=false"* ]]; then
                countdown=259200  # 设置倒计时为初始值
                break  # 跳出内层循环，重新开始倒计时
            fi

            sleep 1  # 等待1秒
        done

        # 执行指令
        echo "执行指令..."
        # 在这里添加您希望在倒计时结束时执行的指令

        # 倒计时结束，退出循环
        break
    fi

    sleep 1  # 等待1秒
done
