#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}

# 这个脚本将以 late_start service 模式执行
# 更多信息请访问 Magisk 主题
#!/system/bin/sh

# 在模块启用时启动倒计时服务
start() {
    # 启动后台倒计时服务
    /system/bin/sh /path/to/post-fs-data.sh &
}

# 在模块禁用时停止倒计时服务
stop() {
    # 停止后台倒计时服务
    pkill -f "/system/bin/sh /path/to/post-fs-data.sh"
}

# 根据命令参数决定启动或停止倒计时服务
case $1 in
    "start")
        start
        ;;
    "stop")
        stop
        ;;
    *)
        echo "Usage: $0 {start|stop}"
        ;;
esac

exit 0
